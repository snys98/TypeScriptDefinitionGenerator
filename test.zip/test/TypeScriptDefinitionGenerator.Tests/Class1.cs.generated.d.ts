export interface Class1 {
    temp: string;
    mas: Mas;
    some: any;
}
export const enum Mas {
    First,
    Next,
}
