	export const enum Some {
		This,
		That,
	}
