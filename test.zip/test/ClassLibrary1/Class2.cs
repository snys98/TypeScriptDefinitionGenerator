﻿namespace ClassLibrary1
{
    public enum Some
    {
        This,
        That
    }
}
